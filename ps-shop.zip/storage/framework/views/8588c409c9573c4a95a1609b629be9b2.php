<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'سبد خرید']); ?>
    <?php
        $num = 0;
    ?>

    <body class="cart">
        <div class="container mt-5">
            <div class="w-75 me-auto mx-auto">
                <?php if(count($carts) == 0): ?>
                    <div class="alert alert-info text-center">
                        سبد خرید شما خالی است
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="col-12 col-sm-12 col-md-6 col-lg-10 col-xl-10 text-center mt-3 border me-auto mx-auto bg-white">
                                <div class="cart-item">
                                    <div class="row">
                                        <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                            <img width="100%" src="<?php echo e(asset('storage/' . $cart->product->cover)); ?>"
                                                alt="">
                                        </div>
                                        <div class="col-10 mt-auto mb-auto col-sm-10 col-md-10 col-lg-10 col-xl-10">
                                            <?php echo e($cart->product->name); ?>

                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                            <input min="1" value="1" price="<?php echo e($cart->product->price); ?>"
                                                onchange="price(this,<?php echo e(++$num); ?>)" class="text-center"
                                                type="number" name="count" max="<?php echo e($cart->product->inventory); ?>"
                                                id="">
                                        </div>
                                        <div id="price<?php echo e($num); ?>"
                                            class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9 text-center">
                                            <?php echo e($cart->product->price); ?> تومان
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="col-12 col-sm-12 col-md-6 col-lg-10 col-xl-10 text-center mt-3 border me-auto mx-auto bg-white">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 mt-3">
                                    <p id="result"></p>

                                </div>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 pt-2 me-auto">
                                    <a class="btn btn-primary w-75" href="">پرداخت</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<script>result();</script>
<?php /**PATH G:\ps-shop\resources\views/pages/cart.blade.php ENDPATH**/ ?>