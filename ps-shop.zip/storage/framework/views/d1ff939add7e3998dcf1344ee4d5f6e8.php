<?php if (isset($component)) { $__componentOriginalc7e2ab31530b26312484d537a31f8e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c = $attributes; } ?>
<?php $component = App\View\Components\Panel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Panel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(count($comments)==0): ?>
        <div class="alert alert-primary text-center">کامنتی جهت نمایش وجود ندارد!</div>
    <?php else: ?>
        
    <table class="table">
        <thead>
          <tr>
            <th scope="col">نویسنده</th>
            <th scope="col">نوشته</th>
            <th scope="col">وضعیت</th>
            <th scope="col">عملیات</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo e($comment->user_id==0 ? 'کاربر مهمان ': optional($comment->writer)->name); ?></td>
                <td><?php echo e($comment->content); ?></td>
                <td>

                  <?php if($comment['status']==1): ?>
                  تایید شده
                  <?php elseif($comment['status']==2): ?>
                  ردشده
                  <?php else: ?>
                  در انتظار
                  <?php endif; ?>

                </td>
                <form action="" method="post">
                  
                </form>
                <td>
                  <div class="d-flex">
                  <form action="<?php echo e(route('comment.update',$comment->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="action" value="2">
                    <button title="رد کامنت" class="btn btn-secondary" href=""><i class="fa fa-times"></i> </button>

                  </form>
                  <form action="<?php echo e(route('comment.update',$comment->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <input type="hidden" name="action" value="1">
                    <button title="تایید کامنت" class="btn btn-success" href=""><i class="fa fa-check"></i> </button>
                  </form>
                  <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="get">
                    <?php echo method_field("DELETE"); ?>
                    <?php echo csrf_field(); ?>
                    <button title="حذف کامنت" class="btn btn-danger" href=""><i class="fa fa-trash"></i></button>
                  </form>
                </div>
                  
                </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $attributes = $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $component = $__componentOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?><?php /**PATH G:\ps-shop\resources\views/user/seller/comments.blade.php ENDPATH**/ ?>