<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($product->name).'']); ?>

    <body class="product">


        <div class="container">
            <div class="back-white">
                <a href=""><?php echo e($product->name); ?></a>/<a href="">دسته بندی</a>
                <div class="row dir-ltr">
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                        <div class="content p-5">
                            <img id="product-img" width="100%"
                                <?php if($product->cover != null): ?> src="<?php echo e(asset("storage/$product->cover")); ?>"
                            <?php else: ?>
                            src="<?php echo e(asset('storage/Product_images/noimage.jpg')); ?>" <?php endif; ?>>
                            <div class="container">
                                <div class="row">
                                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
                                        <img onclick="gallery(this)" class="other-img" width="100%"
                                            src="images/product/3cf0e091a34b6583a12a125f350628c14d7a54c5_1729879355.webp"
                                            alt="">
                                    </div>
                                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
                                        <img onclick="gallery(this)" class="other-img" width="100%"
                                            src="images/product/986c89a39002f22bbfcc0063dcd760089a9fd157_1739716046.webp"
                                            alt="">
                                    </div>
                                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
                                        <img onclick="gallery(this)" class="other-img" width="100%"
                                            src="images/product/e1472bd410b1a8bfa2f21e24093c50a7ef0f2a4e_1715166214.webp"
                                            alt="">
                                    </div>
                                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
                                        <img onclick="gallery(this)" class="other-img" width="100%"
                                            src="images/product/fab87c83a157ddc6416a97acf1709745591715a7_1736173610.webp"
                                            alt="">
                                    </div>
                                </div>
                            </div>
                            <hr class="mt-4 mb-4">
                            <div class="text-center">
                                <!-- ///////////////////موجودی انبار///////////// -->
                                <?php if($product->inventory == 1): ?>
                                    <span class="text-danger">
                                        <i class="fa-solid fa-box-open"></i>
                                        ۱ عدد در انبار باقی مانده </span>
                                <?php elseif($product->inventory > 1): ?>
                                    <span class="text-success">
                                        <i class="fa-solid fa-box-open"></i>

                                        مــوجــود در انـبـار</span>
                                <?php elseif($product->inventory == 0): ?>
                                    <span class="text-primary"><i class="fa-solid fa-box-open"></i>

                                        نا موجود در انبار</span>
                                <?php endif; ?>


                                <!-- ///////////////////موجودی انبار///////////// -->

                                <h6 class="mt-2"> <?php echo e($product->fa_num()); ?> تومان</h6>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(!count($product->Cart)): ?>
                                    <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                        <button class="add-cart">
                                            <i class="fa fa-cart-plus" aria-hidden="true"></i>

                                            افزودن به سبد خرید</button>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(route('cart.destroy',$product->Cart[0]->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>
                                        <button class="add-cart">
                                            <i class="fa fa-cart-plus" aria-hidden="true"></i>

                                            حذف از سبد خرید</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(auth()->guard()->guest()): ?>
                                <a href="<?php echo e(route('login')); ?>">
                                    <button class="add-cart">
                                        <i class="fa fa-cart-plus" aria-hidden="true"></i>

                                        افزودن به سبد خرید</button>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-8 col-xl-8">
                        <div class="content p-5">


                            <h1 class="mb-4">
                                <?php echo e($product->name); ?>

                            </h1>

                            <span>نظرات کاربران: </span> <a href="#comment"><?php echo e(count($comments)); ?> نظر</a>
                            <hr class="mb-5 mt-3 w-50">
                            <p>
                                <?php echo e($product->content); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <form action="<?php echo e(route('comment.store')); ?>" method="Post">
                    <?php echo csrf_field(); ?>
                    <textarea name="comment" class="form-control border-primary"
                        placeholder="خوشحال میشم اگر تجربتون از استفاده این محصول رو در اختیار ما قرار بدید"></textarea>
                    <div class="w-50 me-auto ms-auto">
                        <button class="mt-1 btn border-success form-control">ثبت نظر جدید</button>
                    </div>
                    <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                </form>
                <hr class="mt-2 mb-3" id="comment">
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment p mb-2">
                        <h6><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i>
                            <div class="me-2">
                                <?php if($comment->user_id != 0): ?>
                                    <?php echo e($comment->writer->name); ?> :
                                <?php else: ?>
                                    کاربر مهمان
                                <?php endif; ?>
                            </div>
                        </h6>
                        <hr>
                        <p>
                            <?php echo e($comment->content); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </body>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH G:\ps-shop\resources\views/pages/product.blade.php ENDPATH**/ ?>