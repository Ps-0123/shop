<?php if (isset($component)) { $__componentOriginalc7e2ab31530b26312484d537a31f8e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c = $attributes; } ?>
<?php $component = App\View\Components\Panel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Panel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <form action="" id="form" method="post">
        <label class="mt-3" for="name">نام و نام خانوادگی</label>
        <input value="<?php echo e(Session('user')->name); ?>" readonly class="form-control" type="text" name="name">
        <label class="mt-3" for="name">ایمیل</label>
        <input value="<?php echo e(Session('user')->email); ?>" readonly class="form-control" type="text" name="name">
        <label class="mt-3" for="name">شماره تلفن</label>
        <input value="<?php echo e(Session('user')->mobile); ?>" maxlength="11" readonly class="form-control" type="text" name="name">
        <label class="mt-3" for="name">گذرواژه</label>
        <input value="گذرواژه" readonly class="form-control" type="text" name="name">
        <a class="btn btn-primary mt-3 form-control" onclick="Edit(this)">ویرایش</a>
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $attributes = $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $component = $__componentOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php /**PATH G:\ps-shop\resources\views/user/index.blade.php ENDPATH**/ ?>