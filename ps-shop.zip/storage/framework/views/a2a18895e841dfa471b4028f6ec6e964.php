<?php if (isset($component)) { $__componentOriginalc7e2ab31530b26312484d537a31f8e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c = $attributes; } ?>
<?php $component = App\View\Components\Panel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Panel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <form  action="<?php echo e(route('product.update',$product)); ?>" enctype="multipart/form-data" id="form" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class="mt-3" for="name">نام محصول</label>
        <input value="<?php echo e($product->name); ?>" class="form-control" type="text" name="name">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="content">توضیحات</label>
        <textarea  class="form-control" name="content" cols="30" rows="10"><?php echo e($product->content); ?></textarea>
        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="price">قیمت</label>
        <input value="<?php echo e($product->price); ?>" class="form-control" type="text" name="price">
        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="inventory">موجودی انبار</label>
        <input value="<?php echo e($product->inventory); ?>" min="2" class="form-control" type="number" name="inventory">
        <?php $__errorArgs = ['inventory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="cover">تصویر</label>
        <input type="file" name="cover">
        <button class="btn btn-primary mt-3 form-control">ویرایش</button>
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $attributes = $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $component = $__componentOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php /**PATH G:\ps-shop\resources\views/user/seller/proedit.blade.php ENDPATH**/ ?>