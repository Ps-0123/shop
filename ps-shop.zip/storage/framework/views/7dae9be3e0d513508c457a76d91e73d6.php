<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <body class="dashboard" onload="Selector()">
        <div class="container mt-5">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 text-center">
                    <h5 class="text-end me-3 fw-bold mb-3"><?php echo e(session('user')->name); ?></h5>
                    <div class="content">
                        <ul>
    
                        <a class="a d-block" href="<?php echo e(route('dashboard')); ?>">پروفایل من</a>
                        <?php if(Session('user')->role == 1): ?>
                        <a class="a d-block" href="<?php echo e(route('admin_product')); ?>">مدیریت محصولات</a>
                        <a class="a d-block" href="<?php echo e(route('admin_users')); ?>">مدیریت کاربران</a>
                        <?php endif; ?>
                        <?php if(isset($_COOKIE['product'])): ?>
                        <a target="_blank" class="a d-block" href="<?php echo e(route('product.show',$_COOKIE['product'])); ?>">آخرین بازدید</a>
                        <?php endif; ?>
                        <a class="a d-block" href="#">سفارش ها</a>
                        <a class="a d-block" href="<?php echo e(route('Admin-comment')); ?>">نظرات</a>
                        <a class="a d-block" href="">تیکت ها</a>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
                    <div class="content mt-5 p-5">
                        <?php echo e($slot); ?>


                    </div>
                </div>
            </div>
        </div>
    </body>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH G:\ps-shop\resources\views/components/panel.blade.php ENDPATH**/ ?>