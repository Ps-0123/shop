<?php if (isset($component)) { $__componentOriginalc7e2ab31530b26312484d537a31f8e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c = $attributes; } ?>
<?php $component = App\View\Components\Panel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Panel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['e'=>false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['e'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
    <form  action="<?php if($e): ?><?php echo e(route('product.store')); ?> <?php else: ?> <?php echo e(route('')); ?> <?php endif; ?>" enctype="multipart/form-data" id="form" method="post">
        <?php echo csrf_field(); ?>
        <label class="mt-3" for="name">نام محصول</label>
        <input class="form-control" type="text" name="name">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="content">توضیحات</label>
        <textarea  class="form-control" name="content" cols="30" rows="10"></textarea>
        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="price">قیمت</label>
        <input class="form-control" type="text" name="price">
        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="inventory">موجودی انبار</label>
        <input min="2" class="form-control" type="number" name="inventory">
        <?php $__errorArgs = ['inventory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="mt-3" for="cover">تصویر</label>
        <input type="file" name="cover">
        <button class="btn btn-primary mt-3 form-control">انتشار</button>
    </form>
    <hr class="mt-3 mb-3">
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Content</th>
                <th scope="col">price</th>
                <th scope="col">inventory</th>
                <th scope="col">cover</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->short_content()); ?></td>
                    <td><?php echo e($product->fa_num()); ?></td>
                    <td><?php echo e($product->inventory); ?></td>
                    <td>No</td>
                    <td><a class="btn btn-warning mb-1" href="">ویرایش</a> 
                    <form action="<?php echo e(route('product.destroy',$product->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $attributes = $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $component = $__componentOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php /**PATH G:\ps-shop\resources\views/user/product.blade.php ENDPATH**/ ?>