<?php if (isset($component)) { $__componentOriginalc7e2ab31530b26312484d537a31f8e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c = $attributes; } ?>
<?php $component = App\View\Components\Panel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Panel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">نام </th>
            <th scope="col">ایمیل</th>
            <th scope="col">شماره تلفن</th>
            <th scope="col">نقش کاربر</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->mobile); ?></td>
                <td><div class="btn btn-primary text-white"><?php echo e($user->role()); ?></div></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $attributes = $__attributesOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__attributesOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c)): ?>
<?php $component = $__componentOriginalc7e2ab31530b26312484d537a31f8e4c; ?>
<?php unset($__componentOriginalc7e2ab31530b26312484d537a31f8e4c); ?>
<?php endif; ?><?php /**PATH G:\ps-shop\resources\views/user/seller/user.blade.php ENDPATH**/ ?>