<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title'=>env('APP_NAME')]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title'=>env('APP_NAME')]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($title); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/bootstrap.min.css','resources/css/style.css','resources/js/app.js']); ?>
</head>

<nav class="menu">

    <div class="container">
      <div class="row">
        <ul class="col-10">

          <li><a href="<?php echo e(route('home')); ?>">خانه</a></li>
          <?php if(auth()->guard()->guest()): ?>
          <li><a href="<?php echo e(route('register')); ?>">ثبت نام</a></li>
          <li><a href="<?php echo e(route('login')); ?>">ورود</a></li>
          <?php endif; ?>
          <li><a href="">فروشگاه</a></li>
          <?php if(auth()->guard()->check()): ?>
          <li><a href="<?php echo e(route('dashboard')); ?>">داشبورد</a></li>
            
          <li>
            <form action="<?php echo e(route('logout')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <button class="btn text-white fw-bold">خروج</button>
            </form>
          </li>
          <?php endif; ?>
        </ul>
        <ul class="col-2">
          <li> <a href="<?php echo e(route("cart.index")); ?>">سبد خرید</a></li>

        </ul>
      </div>
    </div>
  </nav>
<?php echo e($slot); ?>

<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</html>
<?php /**PATH G:\ps-shop\resources\views/components/layout.blade.php ENDPATH**/ ?>